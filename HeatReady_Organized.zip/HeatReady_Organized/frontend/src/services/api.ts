const API_BASE = 'http://localhost:8000';

export async function checkHealth() {
    const res = await fetch(`${API_BASE}/health`);
    return res.json();
}

export async function uploadDataset(file: File) {
    const formData = new FormData();
    formData.append('file', file);
    formData.append('dataset_name', file.name);

    const res = await fetch(`${API_BASE}/data/upload`, {
        method: 'POST',
        body: formData
    });
    if (!res.ok) throw new Error(await res.text());
    return res.json();
}

export async function getDatasets() {
    const res = await fetch(`${API_BASE}/data/datasets`);
    if (!res.ok) throw new Error(await res.text());
    return res.json();
}

export async function getProviders(datasetId: string) {
    const res = await fetch(`${API_BASE}/providers/${datasetId}/list`);
    if (!res.ok) throw new Error(await res.text());
    return res.json();
}

export async function getProviderCapacity(providerId: string) {
    const res = await fetch(`${API_BASE}/providers/${providerId}/capacity`);
    if (!res.ok) throw new Error(await res.text());
    return res.json();
}

export async function getForecast(datasetId: string, providerId: string) {
    const res = await fetch(`${API_BASE}/forecasting/${datasetId}/${providerId}`);
    if (!res.ok) throw new Error(await res.text());
    return res.json();
}

export async function simulateScenario(payload: any) {
    const res = await fetch(`${API_BASE}/scenarios/simulate`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(payload)
    });
    if (!res.ok) throw new Error(await res.text());
    return res.json();
}
