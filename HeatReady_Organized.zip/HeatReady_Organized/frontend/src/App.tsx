import React from 'react';
import { Routes, Route, Link, useLocation } from 'react-router-dom';

function Overview() {
    return (
        <div>
            <h1>Overview</h1>
            <p>
                Synthetic demo data platform for Hospital Demand & Heat Surge Planning.
            </p>
        </div>
    );
}

function DataPage() {
    return <div><h1>Data Upload</h1></div>;
}

function ForecastPage() {
    const [latitude, setLatitude] = React.useState('51.5074');
    const [longitude, setLongitude] = React.useState('-0.1278');
    const [loading, setLoading] = React.useState(false);
    const [error, setError] = React.useState('');
    const [forecast, setForecast] = React.useState<{
        timezone: string;
        daily: {
            time: string[];
            temperature_2m_max: (number | null)[];
            temperature_2m_min: (number | null)[];
        };
    } | null>(null);

    async function loadWeather() {
        setError('');
        setForecast(null);

        const lat = Number(latitude);
        const lon = Number(longitude);

        if (
            !latitude.trim() ||
            !longitude.trim() ||
            !Number.isFinite(lat) ||
            !Number.isFinite(lon) ||
            lat < -90 ||
            lat > 90 ||
            lon < -180 ||
            lon > 180
        ) {
            setError('Please enter valid latitude and longitude.');
            return;
        }

        setLoading(true);

        try {
            const params = new URLSearchParams({
                latitude: String(lat),
                longitude: String(lon),
            });

            const response = await fetch(
                `http://localhost:8000/api/weather?${params}`
            );

            if (!response.ok) {
                throw new Error(
                    `Weather request failed (${response.status}).`
                );
            }

            const data = await response.json();

            if (
                !Array.isArray(data.daily?.time) ||
                !Array.isArray(data.daily?.temperature_2m_max) ||
                !Array.isArray(data.daily?.temperature_2m_min)
            ) {
                throw new Error(
                    'The weather response is missing daily data.'
                );
            }

            setForecast(data);
        } catch (err) {
            setError(
                err instanceof Error
                    ? err.message
                    : 'Unable to load weather.'
            );
        } finally {
            setLoading(false);
        }
    }

    return (
        <div>
            <h1>Weather Forecast</h1>
            <p>
                View seven days of weather for your hospital location.
                The default coordinates are for London.
            </p>

            <div
                style={{
                    display: 'flex',
                    gap: 16,
                    flexWrap: 'wrap',
                    alignItems: 'end',
                    marginTop: 20,
                }}
            >
                <label>
                    Latitude
                    <input
                        type="number"
                        step="any"
                        min={-90}
                        max={90}
                        value={latitude}
                        onChange={e => setLatitude(e.target.value)}
                        style={{ display: 'block', padding: 8 }}
                    />
                </label>

                <label>
                    Longitude
                    <input
                        type="number"
                        step="any"
                        min={-180}
                        max={180}
                        value={longitude}
                        onChange={e => setLongitude(e.target.value)}
                        style={{ display: 'block', padding: 8 }}
                    />
                </label>

                <button
                    onClick={loadWeather}
                    disabled={loading}
                    style={{ padding: '10px 16px' }}
                >
                    {loading ? 'Loading…' : 'Get Weather Forecast'}
                </button>
            </div>

            {error && (
                <p role="alert" style={{ color: 'red' }}>
                    {error}
                </p>
            )}

            {forecast && (
                <div style={{ marginTop: 24, overflowX: 'auto' }}>
                    <p>
                        Source: Open-Meteo · Timezone: {forecast.timezone}
                    </p>

                    <table
                        style={{
                            width: '100%',
                            textAlign: 'left',
                            borderCollapse: 'collapse',
                        }}
                    >
                        <thead>
                            <tr>
                                <th style={{ padding: 12 }}>Date</th>
                                <th style={{ padding: 12 }}>Maximum (°C)</th>
                                <th style={{ padding: 12 }}>Minimum (°C)</th>
                            </tr>
                        </thead>

                        <tbody>
                            {forecast.daily.time.map((date, index) => (
                                <tr
                                    key={date}
                                    style={{ borderTop: '1px solid #ddd' }}
                                >
                                    <td style={{ padding: 12 }}>
                                        {date}
                                    </td>
                                    <td style={{ padding: 12 }}>
                                        {forecast.daily.temperature_2m_max[index]
                                            ?? 'Unavailable'}
                                    </td>
                                    <td style={{ padding: 12 }}>
                                        {forecast.daily.temperature_2m_min[index]
                                            ?? 'Unavailable'}
                                    </td>
                                </tr>
                            ))}
                        </tbody>
                    </table>

                    <p>
                        These are weather forecasts. Hospital-demand predictions
                        require a separate model using hospital data.
                    </p>
                </div>
            )}
        </div>
    );
}

function ScenarioBuilder() {
    return <div><h1>Scenario Builder</h1></div>;
}

function ResourceRisk() {
    return <div><h1>Resource Risk</h1></div>;
}

function Comparison() {
    return <div><h1>What-if Comparison</h1></div>;
}

function SavedAnalyses() {
    return <div><h1>Saved Analyses</h1></div>;
}

function Methodology() {
    return <div><h1>Methodology</h1></div>;
}

export default function App() {
    const location = useLocation();

    const navLinks = [
        { path: '/', label: 'Overview' },
        { path: '/data', label: 'Data & Validation' },
        { path: '/forecast', label: 'Forecast' },
        { path: '/scenario', label: 'Scenario Builder' },
        { path: '/risk', label: 'Resource Risk' },
        { path: '/comparison', label: 'What-if Comparison' },
        { path: '/saved', label: 'Saved Analyses' },
        { path: '/methodology', label: 'Methodology' },
    ];

    return (
        <div className="dashboard">
            <div className="sidebar">
                <div className="sidebar-title">HeatReady</div>

                {navLinks.map(link => (
                    <Link
                        key={link.path}
                        to={link.path}
                        className={`sidebar-link ${location.pathname === link.path ? 'active' : ''
                            }`}
                    >
                        {link.label}
                    </Link>
                ))}
            </div>

            <div className="main-content">
                <Routes>
                    <Route path="/" element={<Overview />} />
                    <Route path="/data" element={<DataPage />} />
                    <Route path="/forecast" element={<ForecastPage />} />
                    <Route path="/scenario" element={<ScenarioBuilder />} />
                    <Route path="/risk" element={<ResourceRisk />} />
                    <Route path="/comparison" element={<Comparison />} />
                    <Route path="/saved" element={<SavedAnalyses />} />
                    <Route path="/methodology" element={<Methodology />} />
                </Routes>
            </div>
        </div>
    );
}