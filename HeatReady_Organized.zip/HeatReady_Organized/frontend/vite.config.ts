import { defineConfig } from 'vite'
import react from '@vitejs/plugin-react'
import * as path from 'path'; // Need to be careful, vite might fail if @types/node missing. I will avoid aliases for now to save time.

// https://vitejs.dev/config/
export default defineConfig({
    plugins: [react()],
})
