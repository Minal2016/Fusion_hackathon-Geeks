# HeatReady — Hospital Demand & Heat Surge Planning

An operational dashboard simulating hospital constraints and demand exceedances under extreme heat surge scenarios utilizing strictly bounded probabilistic analytics.

## Tech Stack
- Frontend: React 18, Vite, TypeScript
- Backend: Python 3, FastAPI, Pandas, NumPy, Pytest
- Database: Firebase Firestore

## Requirements
- Python 3.9+
- Node.js 18+ (npm)

## Local Installation Guide

### Backend Server Setup (Windows)
```powershell
cd backend
python -m venv venv
.\venv\Scripts\activate
pip install -r requirements.txt
# Generate reproducible demo baseline dataset
python scripts\generate_sample_data.py
# Start the FastAPI Rest service
uvicorn app.main:app --reload --port 8000
```

### Backend Server Setup (macOS / Linux)
```bash
cd backend
python3 -m venv venv
source venv/bin/activate
pip install -r requirements.txt
python scripts/generate_sample_data.py
uvicorn app.main:app --reload --port 8000
```

### Frontend Server Setup (All OS)
```bash
cd frontend
npm install
npm run dev
```
Access the dashboard via `http://localhost:5173`.

### Firebase Note
The backend currently points to the Firebase App initialized locally in `backend/app/database.py`. In an air-gapped run context, please export the `FIRESTORE_EMULATOR_HOST=127.0.0.1:8080` variable against a local firebase simulator, or ensure correct GCP SDK service account credential injection.

## Running Tests
Tests are located in the `backend/tests` module verifying zero leakage, strict reproducibility bounds, and constraint validations.
From inside the `backend/` directory:
```bash
python -m pytest tests/
```
