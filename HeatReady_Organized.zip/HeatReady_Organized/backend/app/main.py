from fastapi import HTTPException, Query
from .services.weather_service import get_weather
import requests
from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from .routers import base

app = FastAPI(
    title="HeatReady API",
    description="Backend for HeatReady - Hospital Demand & Heat Surge Planning",
    version="1.0.0"
)

# Restrict CORS to configured development origins (localhost for now)
app.add_middleware(
    CORSMiddleware,
    allow_origins=["http://localhost:5173", "http://127.0.0.1:5173"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

app.include_router(base.router)

from .routers import data, providers, forecasting, simulation
app.include_router(data.router)
app.include_router(providers.router)
app.include_router(forecasting.router)
app.include_router(simulation.router)
@app.get("/api/weather")
def weather_forecast(
    latitude: float = Query(51.5074, ge=-90, le=90),
    longitude: float = Query(-0.1278, ge=-180, le=180),
):
    try:
        return get_weather(latitude, longitude)
    except requests.RequestException:
        raise HTTPException(
            status_code=502,
            detail="Weather service unavailable. Please try again.",
        )
