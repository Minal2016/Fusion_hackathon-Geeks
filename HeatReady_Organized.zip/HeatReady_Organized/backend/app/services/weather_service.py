import requests

def get_weather(latitude, longitude):
    response = requests.get(
        "https://api.open-meteo.com/v1/forecast",
        params={
            "latitude": latitude,
            "longitude": longitude,
            "hourly": (
                "temperature_2m,relative_humidity_2m,"
                "apparent_temperature"
            ),
            "daily": "temperature_2m_max,temperature_2m_min",
            "forecast_days": 7,
            "timezone": "auto",
        },
        timeout=20,
    )
    response.raise_for_status()
    return response.json()

# Example: London; use your hospital's coordinates.
if __name__ == "__main__":
    weather = get_weather(51.5074, -0.1278)
    print(weather["daily"])
    