import numpy as np

def run_scenario_simulation(
    forecast_attendances: int,
    days_in_month: int,
    capacities: dict,
    assumptions: dict,
    temperatures: list # list of 3 daily temperatures
) -> dict:
    
    np.random.seed(42)
    n_traj = 2000
    
    # Base daily arrivals
    daily_base_arrivals = forecast_attendances / days_in_month
    
    # Extract capacities
    total_beds = capacities.get('total_beds', 0)
    icu_beds = capacities.get('icu_beds', 0)
    amb_cap = capacities.get('ambulance_capacity_hours', 0)
    staff_cap = capacities.get('clinical_staff_hours', 0)
    inventory_cap = capacities.get('inventory_units', 1000)
    
    # Initial occupancy (random baseline)
    initial_occ = min(int(total_beds * 0.8), total_beds)
    
    threshold = assumptions.get('heat_threshold', 25.0)
    arrival_frac_per_deg = assumptions.get('additional_arrival_frac_per_degree', 0.05)
    vuln_multiplier = assumptions.get('vulnerability_multiplier', 1.0)
    adm_frac = assumptions.get('admission_fraction', 0.25)
    heat_adm_frac = assumptions.get('heat_admission_fraction', 0.40)
    icu_frac = assumptions.get('icu_fraction', 0.10)
    
    results = {
        'total_admissions': np.zeros(n_traj),
        'max_occupied_beds': np.zeros(n_traj),
        'max_icu_beds': np.zeros(n_traj),
        'total_amb_hours': np.zeros(n_traj),
        'total_staff_hours': np.zeros(n_traj),
        'total_inventory': np.zeros(n_traj),
        'exceedance_beds': 0,
        'exceedance_icu': 0,
        'exceedance_amb': 0,
        'exceedance_staff': 0,
        'exceedance_inventory': 0
    }
    
    # For each trajectory, simulate 3 days
    for i in range(n_traj):
        occ = initial_occ
        icu_occ = int(initial_occ * 0.1) # approx starting ICU
        
        traj_total_admissions = 0
        traj_max_beds = occ
        traj_max_icu = icu_occ
        traj_amb = 0
        traj_staff = 0
        traj_inventory = 0
        
        for temp in temperatures:
            deg_above = max(0, temp - threshold)
            
            # Additional arrivals base
            additional = np.random.poisson(daily_base_arrivals * deg_above * arrival_frac_per_deg * vuln_multiplier)
            base_arr = np.random.poisson(daily_base_arrivals)
            
            total_arr = base_arr + additional
            
            # Admitted
            base_adm = np.random.binomial(base_arr, adm_frac)
            heat_adm = np.random.binomial(additional, heat_adm_frac) if additional > 0 else 0
            
            total_adm = base_adm + heat_adm
            traj_total_admissions += total_adm
            
            # Approx discharges (e.g. 20% of beds free up daily)
            discharges = np.random.binomial(occ, 0.2)
            occ = max(0, occ - discharges + total_adm)
            if occ > traj_max_beds: traj_max_beds = occ
            
            new_icu = np.random.binomial(total_adm, icu_frac) if total_adm > 0 else 0
            icu_discharges = np.random.binomial(icu_occ, 0.2)
            icu_occ = max(0, icu_occ - icu_discharges + new_icu)
            
            # Constrain ICU to total beds max
            if icu_occ > occ: icu_occ = occ
            if icu_occ > traj_max_icu: traj_max_icu = icu_occ
            
            # Resource consumptions
            traj_amb += np.random.normal(total_arr * 0.5, total_arr * 0.1)
            traj_staff += np.random.normal(total_arr * 1.5, total_arr * 0.2) + np.random.normal(occ * 4, occ * 0.5)
            traj_inventory += np.random.poisson(total_arr * 2.0 + occ * 1.5) # Accumulates
            
        results['total_admissions'][i] = traj_total_admissions
        results['max_occupied_beds'][i] = traj_max_beds
        results['max_icu_beds'][i] = traj_max_icu
        results['total_amb_hours'][i] = traj_amb / len(temperatures) # per day
        results['total_staff_hours'][i] = traj_staff / len(temperatures) # per day
        results['total_inventory'][i] = traj_inventory # Cumulative
        
        # Check exceedances
        if traj_max_beds > total_beds: results['exceedance_beds'] += 1
        if traj_max_icu > icu_beds: results['exceedance_icu'] += 1
        if (traj_amb / len(temperatures)) > amb_cap: results['exceedance_amb'] += 1
        if (traj_staff / len(temperatures)) > staff_cap: results['exceedance_staff'] += 1
        if traj_inventory > inventory_cap: results['exceedance_inventory'] += 1

    summary = {}
    for k in ['total_admissions', 'max_occupied_beds', 'max_icu_beds', 'total_amb_hours', 'total_staff_hours', 'total_inventory']:
        summary[k] = {
            "p10": round(np.percentile(results[k], 10)),
            "p50": round(np.percentile(results[k], 50)),
            "p90": round(np.percentile(results[k], 90)),
        }
        
    summary['exceedance'] = {
        "beds": results['exceedance_beds'] / n_traj,
        "icu": results['exceedance_icu'] / n_traj,
        "ambulance": results['exceedance_amb'] / n_traj,
        "staff": results['exceedance_staff'] / n_traj,
        "inventory": results['exceedance_inventory'] / n_traj,
    }
        
    return summary
