import pandas as pd
import numpy as np

def forecast_provider_demand(df: pd.DataFrame, target_col: str = "attendances") -> dict:
    # df must be sorted chronologically and have no missing months
    df['parsed_month'] = pd.to_datetime(df['month'])
    df = df.sort_values('parsed_month').reset_index(drop=True)
    
    # We require 36 months, holdout is last 12 months for rolling validation
    # If len(df) < 36, it should have been caught in validation
    
    n = len(df)
    train_size_initial = n - 12
    
    methods = ["last_year", "3mo_avg", "seasonally_adjusted"]
    errors = {m: [] for m in methods}
    forecasts_list = {m: [] for m in methods}
    actuals = []
    
    # Expanding window validation on last 12 months
    for t in range(train_size_initial, n):
        train = df[target_col].iloc[:t].values
        actual = df[target_col].iloc[t]
        actuals.append(actual)
        
        # 1. Same month last year (lag 12)
        if t >= 12:
            f_ly = train[t-12]
        else:
            f_ly = train[-1]
            
        # 2. 3-mo avg
        f_3mo = np.mean(train[-3:])
        
        # 3. Seasonally adjusted baseline
        # Mean of target month over past years
        # E.g. t % 12 gives the month index (roughly, if aligned).
        # We find indices in train where the month is same as t's month
        t_month_num = df['parsed_month'].iloc[t].month
        train_months = df['parsed_month'].iloc[:t].dt.month
        hist_same_month = train[train_months == t_month_num]
        
        f_sa = np.mean(hist_same_month) if len(hist_same_month) > 0 else f_ly
        
        forecasts_list["last_year"].append(f_ly)
        forecasts_list["3mo_avg"].append(f_3mo)
        forecasts_list["seasonally_adjusted"].append(f_sa)
        
        errors["last_year"].append(abs(f_ly - actual))
        errors["3mo_avg"].append(abs(f_3mo - actual))
        errors["seasonally_adjusted"].append(abs(f_sa - actual))
        
    # Calculate MAEs
    maes = {m: np.mean(errors[m]) for m in methods}
    
    # Select best
    best_method = min(maes, key=maes.get)
    
    # Calculate Empirical P10/P50/P90 based on holdout residuals
    best_forecasts = np.array(forecasts_list[best_method])
    actuals_arr = np.array(actuals)
    residuals = actuals_arr - best_forecasts
    
    # Generate final forecast for next month (n)
    full_train = df[target_col].values
    next_t = n
    
    f_ly_next = full_train[n-12]
    f_3mo_next = np.mean(full_train[-3:])
    
    next_month_num = (df['parsed_month'].iloc[-1].month % 12) + 1
    full_months = df['parsed_month'].dt.month
    hist_next_month = full_train[full_months == next_month_num]
    f_sa_next = np.mean(hist_next_month) if len(hist_next_month) > 0 else f_ly_next
    
    forecast_values = {
        "last_year": f_ly_next,
        "3mo_avg": f_3mo_next,
        "seasonally_adjusted": f_sa_next
    }
    point_forecast = forecast_values[best_method]
    
    # ranges
    q10 = np.percentile(residuals, 10)
    q50 = np.percentile(residuals, 50)
    q90 = np.percentile(residuals, 90)
    
    return {
        "selected_method": best_method,
        "evaluation_observations": len(actuals),
        "mae": maes[best_method],
        "seasonal_baseline_mae": maes["seasonally_adjusted"],
        "next_month_point_forecast": round(point_forecast),
        "p10": max(0, round(point_forecast + q10)),
        "p50": max(0, round(point_forecast + q50)),
        "p90": max(0, round(point_forecast + q90)),
        "metrics": maes
    }
