import pandas as pd
from typing import Tuple, Dict, Any, List
from io import BytesIO

def validate_dataset(file_content: bytes) -> Tuple[bool, Dict[str, Any], pd.DataFrame]:
    try:
        df = pd.read_csv(BytesIO(file_content))
    except Exception as e:
        return False, {"error": "Invalid CSV file format.", "details": str(e)}, pd.DataFrame()
        
    required_cols = {'month', 'provider', 'attendances', 'admissions'}
    if not required_cols.issubset(set(df.columns)):
        return False, {"error": f"Missing required columns. Expected at least {required_cols}"}, df
        
    # Validation Rules
    errors = []
    
    # 1. Non-empty provider identifiers
    if df['provider'].isnull().any() or (df['provider'] == '').any():
        errors.append("Provider identifiers cannot be empty.")
        
    # 2. Month format YYYY-MM
    try:
        df['parsed_month'] = pd.to_datetime(df['month'], format='%Y-%m', errors='raise')
    except Exception:
        errors.append("Month column must be exactly in YYYY-MM format.")
        
    # 3. Nonnegative whole counts
    for col in ['attendances', 'admissions']:
        if not pd.api.types.is_numeric_dtype(df[col]):
            errors.append(f"Column '{col}' must be numeric.")
        elif (df[col] < 0).any():
            errors.append(f"Column '{col}' cannot contain negative values.")
        elif not (df[col].fillna(0) == df[col].fillna(0).astype(int)).all():
            errors.append(f"Column '{col}' must be whole numbers.")
            
    # 4. Duplicate observations
    if df.duplicated(subset=['provider', 'month']).any():
        errors.append("Duplicate provider/month observations found.")
        
    if errors:
        return False, {"error": "Validation failed", "issues": errors}, df
        
    # 5. Missing months check (consecutiveness) per provider
    # and require at least 36 consecutive months
    for provider, group in df.groupby('provider'):
        group = group.sort_values('parsed_month')
        if len(group) < 36:
            errors.append(f"Provider {provider} has {len(group)} months (requires >= 36).")
            continue
            
        # Check consecutiveness
        months_diff = group['parsed_month'].diff().dropna().dt.days
        # If any diff > 31 days (meaning skipping a month), they aren't consecutive
        # Pandas diff on month start gives 28, 29, 30, 31 days.
        if (months_diff > 31).any():
            errors.append(f"Provider {provider} does not have consecutive months (missing months found).")
            
    if errors:
        return False, {"error": "Validation failed", "issues": errors}, df
        
    return True, {"message": "Valid", "issues": []}, df
