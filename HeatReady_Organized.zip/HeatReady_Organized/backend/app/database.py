import os
import firebase_admin
from firebase_admin import credentials
from firebase_admin import firestore

# Determine if we should use a mock credential (for emulator/offline mode)
# In production, GOOGLE_APPLICATION_CREDENTIALS must be set.
def get_db():
    if not firebase_admin._apps:
        emulator_host = os.environ.get("FIRESTORE_EMULATOR_HOST")
        if emulator_host:
            # We are using the emulator, we can use a dummy credential
            from firebase_admin.credentials import ApplicationDefault
            # Firebase admin might complain about missing credentials, 
            # but if FIRESTORE_EMULATOR_HOST is set, we can mock it
            app_cred = credentials.Certificate({"type": "service_account", "project_id": "heatready-demo", "private_key_id": "dummy", "private_key": "-----BEGIN PRIVATE KEY-----\ndummy\n-----END PRIVATE KEY-----\n", "client_email": "dummy@dummy.com", "client_id": "dummy", "auth_uri": "https://accounts.google.com/o/oauth2/auth", "token_uri": "https://oauth2.googleapis.com/token", "auth_provider_x509_cert_url": "https://www.googleapis.com/oauth2/v1/certs", "client_x509_cert_url": "https://www.googleapis.com/robot/v1/metadata/x509/dummy@dummy.com"})
            try:
                firebase_admin.initialize_app(app_cred, {"projectId": "heatready-demo"})
            except ValueError:
                pass # Already initialized
        else:
            # Requires GOOGLE_APPLICATION_CREDENTIALS in .env or environment
            cred = credentials.ApplicationDefault()
            firebase_admin.initialize_app(cred, {"projectId": "heatready-demo"})
            
    db = firestore.client()
    return db
