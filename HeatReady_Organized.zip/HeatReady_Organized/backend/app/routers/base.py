from fastapi import APIRouter

router = APIRouter()

@router.get("/health")
def health_check():
    return {"status": "ok", "app": "HeatReady", "database": "firestore_configured"}
