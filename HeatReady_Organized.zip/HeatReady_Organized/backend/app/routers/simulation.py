from fastapi import APIRouter, HTTPException
from pydantic import BaseModel
from typing import List, Dict
import os
import uuid
import datetime

from ..database import get_db
from ..services.simulation import run_scenario_simulation

router = APIRouter(prefix="/scenarios", tags=["scenarios"])

class ScenarioRunner(BaseModel):
    dataset_id: str
    provider_id: str
    forecast_attendances: int
    days_in_month: int
    temperatures: List[float]
    assumptions: Dict[str, float]
    # Optionally pass different capacity config for "what-if" comparison
    override_capacity: dict = None

@router.post("/simulate")
def simulate_scenario(req: ScenarioRunner):
    db = get_db()
    
    if req.override_capacity:
        caps = req.override_capacity
    else:
        # Load from DB
        cap_ref = db.collection('provider_capacities').document(req.provider_id)
        doc = cap_ref.get()
        if not doc.exists:
            # Fallback
            caps = {
                "total_beds": 500,
                "icu_beds": 50,
                "ambulance_capacity_hours": 240,
                "clinical_staff_hours": 1200
            }
        else:
            caps = doc.to_dict()
            
    res = run_scenario_simulation(
        req.forecast_attendances,
        req.days_in_month,
        caps,
        req.assumptions,
        req.temperatures
    )
    
    return {
        "scenario_id": str(uuid.uuid4()),
        "capacity_used": caps,
        "results": res
    }
    
class SnapshotMetadata(BaseModel):
    scenario_id: str
    provider_id: str
    dataset_id: str
    payload: dict

@router.post("/save")
def save_snapshot(snap: SnapshotMetadata):
    db = get_db()
    ds_ref = db.collection('snapshots').document(snap.scenario_id)
    doc_data = snap.dict()
    doc_data['timestamp'] = datetime.datetime.now().isoformat()
    ds_ref.set(doc_data)
    return {"status": "ok", "scenario_id": snap.scenario_id}

@router.get("/snapshots")
def get_snapshots():
    db = get_db()
    docs = db.collection('snapshots').stream()
    return [doc.to_dict() for doc in docs]
