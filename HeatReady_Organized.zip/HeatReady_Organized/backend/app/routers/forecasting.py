from typing import Optional

from fastapi import APIRouter, HTTPException, Query
import pandas as pd
import requests

from ..database import get_db
from ..services.forecasting import forecast_provider_demand
from ..services.weather_service import get_weather


router = APIRouter(
    prefix="/forecasting",
    tags=["forecasting"],
)


@router.get("/{dataset_id}/{provider_id}")
def generate_forecast(
    dataset_id: str,
    provider_id: str,
    latitude: Optional[float] = Query(None, ge=-90, le=90),
    longitude: Optional[float] = Query(None, ge=-180, le=180),
):
    # Weather is optional, but requires both coordinates.
    if (latitude is None) != (longitude is None):
        raise HTTPException(
            status_code=400,
            detail="Provide both latitude and longitude.",
        )

    db = get_db()
    ds_ref = db.collection("datasets").document(dataset_id)

    if not ds_ref.get().exists:
        raise HTTPException(
            status_code=404,
            detail="Dataset not found",
        )

    observations = (
        ds_ref.collection("observations")
        .where("provider", "==", provider_id)
        .stream()
    )

    data = [doc.to_dict() for doc in observations]

    if len(data) < 36:
        raise HTTPException(
            status_code=400,
            detail="Insufficient data for forecasting. Need >= 36 months.",
        )

    df = pd.DataFrame(data)

    # Existing monthly hospital-demand model.
    result = forecast_provider_demand(df, "attendances")

    df = df.sort_values("parsed_month")

    history = df[
        ["month", "attendances", "admissions"]
    ].to_dict(orient="records")

    forecast_month = (
        df["parsed_month"].iloc[-1].to_period("M") + 1
    ).strftime("%Y-%m")

    weather = None
    weather_status = "not_requested"
    weather_message = "Provide hospital coordinates to include weather."

    if latitude is not None and longitude is not None:
        try:
            weather = get_weather(latitude, longitude)
            weather_status = "available"
            weather_message = (
                "Weather is returned for context. "
                "It does not modify the hospital-demand prediction."
            )
        except (requests.RequestException, ValueError):
            weather_status = "unavailable"
            weather_message = (
                "Weather could not be loaded. "
                "The hospital-demand forecast is still available."
            )

    return {
        "history": history,
        "forecast": result,
        "forecast_month": forecast_month,
        "target": "attendances",
        "forecast_frequency": "monthly",
        "weather": weather,
        "weather_status": weather_status,
        "weather_message": weather_message,
        "weather_adjustment_applied": False,
        "methodology": (
            "Monthly demand uses the method with the lowest MAE "
            "over the final 12 historical months. "
            "P10/P50/P90 are empirical residual-based estimates; "
            "their coverage has not been calibrated. "
            "Weather covers the upcoming seven days, which may "
            "differ from the hospital forecast month."
        ),
    }