from fastapi import APIRouter, HTTPException
from typing import List
from ..schemas.provider import ProviderCapacity, ProviderUpdate
from ..database import get_db

router = APIRouter(prefix="/providers", tags=["providers"])

@router.get("/{dataset_id}/list")
def list_providers(dataset_id: str):
    db = get_db()
    
    ds_ref = db.collection('datasets').document(dataset_id)
    if not ds_ref.get().exists:
        raise HTTPException(status_code=404, detail="Dataset not found")
        
    obs = ds_ref.collection('observations').stream()
    providers = set()
    for o in obs:
        providers.add(o.to_dict().get("provider"))
        
    return {"providers": list(providers)}

@router.get("/{provider_id}/capacity", response_model=ProviderCapacity)
def get_capacity(provider_id: str):
    db = get_db()
    cap_ref = db.collection('provider_capacities').document(provider_id)
    doc = cap_ref.get()
    if doc.exists:
        data = doc.to_dict()
        return ProviderCapacity(provider_id=provider_id, **data)
        
    # Default fallback capacity
    default = {
        "provider_id": provider_id,
        "total_beds": 500,
        "icu_beds": 50,
        "ambulance_capacity_hours": 240,
        "clinical_staff_hours": 1200
    }
    cap_ref.set(default)
    return ProviderCapacity(**default)

@router.put("/{provider_id}/capacity", response_model=ProviderCapacity)
def update_capacity(provider_id: str, cap: ProviderUpdate):
    db = get_db()
    cap_ref = db.collection('provider_capacities').document(provider_id)
    data = cap.dict()
    cap_ref.set(data, merge=True)
    return ProviderCapacity(provider_id=provider_id, **data)
