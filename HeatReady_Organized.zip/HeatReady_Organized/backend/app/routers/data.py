from fastapi import APIRouter, UploadFile, File, HTTPException
from fastapi.responses import FileResponse
from pydantic import BaseModel
from typing import List, Optional
import os
import uuid
import datetime

from ..services.ingestion import validate_dataset
from ..database import get_db

router = APIRouter(prefix="/data", tags=["data"])

class DatasetMeta(BaseModel):
    id: str
    name: str
    status: str
    evidence_label: str
    upload_time: str
    source_url: Optional[str] = None
    aggregation_level: str
    coverage_dates: str

@router.get("/sample")
def get_sample_dataset():
    file_path = os.path.join(os.path.dirname(__file__), '..', '..', 'data', 'sample_dataset.csv')
    if not os.path.exists(file_path):
        raise HTTPException(status_code=404, detail="Sample dataset not found.")
    return FileResponse(file_path, filename="synthetic_sample_dataset.csv")

@router.post("/upload", response_model=DatasetMeta)
async def upload_dataset(file: UploadFile = File(...), source_url: Optional[str] = None, dataset_name: str = "Uploaded Dataset"):
    content = await file.read()
    is_valid, validation_result, df = validate_dataset(content)
    
    if not is_valid:
        raise HTTPException(status_code=400, detail=validation_result)

    # Save to Firestore
    db = get_db()
    dataset_id = str(uuid.uuid4())
    
    # Coverage dates
    min_date = df['month'].min()
    max_date = df['month'].max()
    
    metadata = {
        "id": dataset_id,
        "name": dataset_name,
        "status": "active",
        "evidence_label": "Synthetic demo data" if "sample" in file.filename.lower() else "User Uploaded",
        "upload_time": datetime.datetime.now().isoformat(),
        "source_url": source_url,
        "aggregation_level": "provider_monthly",
        "coverage_dates": f"{min_date} to {max_date}"
    }
    
    # Batch write observations
    batch = db.batch()
    ds_ref = db.collection('datasets').document(dataset_id)
    batch.set(ds_ref, metadata)
    
    # Store records in subcollection for ease
    count = 1
    for _, row in df.iterrows():
        obs_ref = ds_ref.collection('observations').document()
        batch.set(obs_ref, {
            "month": row['month'],
            "provider": row['provider'],
            "attendances": int(row['attendances']),
            "admissions": int(row['admissions'])
        })
        count += 1
        # Firestore batch limit is 500
        if count % 450 == 0:
            batch.commit()
            batch = db.batch()
            
    if count % 450 != 0:
        batch.commit()
        
    return metadata
    
@router.get("/datasets", response_model=List[DatasetMeta])
def list_datasets():
    db = get_db()
    docs = db.collection('datasets').stream()
    return [doc.to_dict() for doc in docs]
