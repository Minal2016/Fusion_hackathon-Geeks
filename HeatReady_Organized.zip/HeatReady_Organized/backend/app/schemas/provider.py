from pydantic import BaseModel

class ProviderCapacity(BaseModel):
    provider_id: str
    total_beds: int
    icu_beds: int
    ambulance_capacity_hours: int
    clinical_staff_hours: int
    inventory_units: int
    
class ProviderUpdate(BaseModel):
    total_beds: int
    icu_beds: int
    ambulance_capacity_hours: int
    clinical_staff_hours: int
    inventory_units: int
