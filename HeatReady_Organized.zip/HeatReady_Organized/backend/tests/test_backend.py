import pytest
from app.services.simulation import run_scenario_simulation
from app.services.forecasting import forecast_provider_demand
import pandas as pd
import numpy as np

def test_simulation_bounds_and_percentiles():
    capacities = {
        "total_beds": 100,
        "icu_beds": 10,
        "ambulance_capacity_hours": 100,
        "clinical_staff_hours": 300
    }
    
    assumptions = {
        "heat_threshold": 25.0,
        "additional_arrival_frac_per_degree": 0.05,
        "vulnerability_multiplier": 1.0,
        "admission_fraction": 0.25,
        "heat_admission_fraction": 0.40,
        "icu_fraction": 0.10
    }
    
    res1 = run_scenario_simulation(3000, 30, capacities, assumptions, [28.0, 30.0, 32.0])
    
    # 1. Percentiles are ordered
    for metric in ['total_admissions', 'max_occupied_beds', 'max_icu_beds']:
        assert res1[metric]['p10'] <= res1[metric]['p50']
        assert res1[metric]['p50'] <= res1[metric]['p90']
        
    # 2. Probabilities stay between zero and one
    for k, v in res1['exceedance'].items():
        assert 0.0 <= v <= 1.0
        
    # 3. ICU demand is a subset of total occupied-bed demand
    # Since percentiles might drift, we test if p90 icu <= p90 beds
    assert res1['max_icu_beds']['p90'] <= res1['max_occupied_beds']['p90']
    
    # 4. Increased capacity does not increase exceedance
    capacities2 = capacities.copy()
    capacities2['total_beds'] = 500
    res2 = run_scenario_simulation(3000, 30, capacities2, assumptions, [28.0, 30.0, 32.0])
    
    assert res2['exceedance']['beds'] <= res1['exceedance']['beds']

def test_fixed_seeds_reproduce():
    # In run_scenario_simulation, we use np.random.seed(42), so running it twice with same args should yield identical results
    capacities = {"total_beds": 100, "icu_beds": 10}
    assumptions = {}
    r1 = run_scenario_simulation(2000, 30, capacities, assumptions, [25.0, 25.0, 25.0])
    r2 = run_scenario_simulation(2000, 30, capacities, assumptions, [25.0, 25.0, 25.0])
    assert r1 == r2
    
def test_forecasting_leakage():
    # Construct a simple dataframe
    dates = pd.date_range('2020-01-01', periods=40, freq='MS').strftime('%Y-%m')
    df = pd.DataFrame({
        'month': dates,
        'provider': 'P-1',
        'attendances': np.random.randint(100, 200, 40),
        'admissions': np.random.randint(20, 50, 40)
    })
    
    res = forecast_provider_demand(df)
    # Ensure next month forecast is calculated
    assert 'next_month_point_forecast' in res
    assert res['evaluation_observations'] == 12 # Because it tests on the last 12 months
