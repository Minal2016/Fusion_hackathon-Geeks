import pandas as pd
import numpy as np
from datetime import datetime
from dateutil.relativedelta import relativedelta
import os

def generate_sample_data():
    np.random.seed(42) # Reproducible seed
    providers = ["PROVIDER-A", "PROVIDER-B", "PROVIDER-C"]
    
    # 48 months ending with last month
    end_date = datetime(2025, 12, 1)
    start_date = end_date - relativedelta(months=47)
    
    months = pd.date_range(start=start_date, end=end_date, freq='MS').strftime("%Y-%m").tolist()
    
    data = []
    
    for provider in providers:
        # Base attendance level
        base_attendances = np.random.randint(3000, 8000)
        
        # Admission rate roughly 20-30%
        base_admissions_rate = np.random.uniform(0.20, 0.30)
        
        for i, month in enumerate(months):
            # Add some seasonality (winter peak, summer peak)
            month_num = int(month.split('-')[1])
            seasonality = 1.0
            if month_num in [12, 1, 2]: # Winter
                seasonality = 1.15
            elif month_num in [7, 8]: # Summer
                seasonality = 1.05
                
            # Add some noise
            noise = np.random.normal(1.0, 0.05)
            
            attendances = int(base_attendances * seasonality * noise)
            admissions = int(attendances * base_admissions_rate * np.random.normal(1.0, 0.03))
            
            data.append({
                "month": month,
                "provider": provider,
                "attendances": attendances,
                "admissions": admissions
            })
            
    df = pd.DataFrame(data)
    
    # Make sure target directory exists
    os.makedirs(os.path.join(os.path.dirname(__file__), '..', 'data'), exist_ok=True)
    df.to_csv(os.path.join(os.path.dirname(__file__), '..', 'data', 'sample_dataset.csv'), index=False)
    print("Synthetic sample data generated at data/sample_dataset.csv")

if __name__ == "__main__":
    generate_sample_data()
