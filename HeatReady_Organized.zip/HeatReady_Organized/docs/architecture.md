# Architecture

## Overview
HeatReady is designed with a decoupled architecture employing a Python FastAPI REST backend and a React/TypeScript Vite frontend.

## Components
- **Backend (`/backend`)**:
  - Framework: FastAPI
  - Data Analytics: Pandas, NumPy
  - Database: Firebase Firestore via `firebase-admin` library (Provides local resilience and online persistence)
  - Core Modules:
    - `/services/forecasting.py`: Rolling-window holdout validation, MAE metrics, and point forecasting.
    - `/services/simulation.py`: Poisson & Binomial distributions simulating >2000 trajectories for robustness mapping bounds (P10/P50/P90).
    - `/services/ingestion.py`: CSV validation and sanitization.

- **Frontend (`/frontend`)**:
  - Framework: React 18 & Vite
  - Visualizations: Recharts
  - Styling: Vanilla CSS focusing on dark mode usability (Navy/Teal).

## Integration
The frontend accesses the API uniformly across standard endpoints on `localhost:8000`. Caching is employed in React states or URL routing parameters rather than complex Redux stores for immediate rapid iteration feedback.
