# HeatReady Demonstration Script (3-Minutes)

**0:00 - 0:30 | Introduction & Data Loading**
"Welcome to HeatReady, a transparent hospital demand and capacity planner.
We explicitly declare this is built on verifiable mathematical boundaries, rather than hallucinated AI probabilities avoiding critical clinical risks.
*Action: Display the main UI. Navigate to the Data view and click Upload, parsing the synthetic demo CSV.*
Notice how we enforce data honesty—we strictly validate assumptions ensuring month-consecutive structure and prevent obfuscated negative counts."

**0:30 - 1:15 | Baseline Diagnostics**
*Action: Click the Provider selector and load the Forecast chart.*
"Out in the field, we require resilient baselines before injecting assumptions. Here we use an expanding backtested holdout selection pulling from seasonal lag methods. Observe the P10 to P90 bounds representing genuine historical error distributions based completely on the prior residuals."

**1:15 - 2:15 | Operational Simulation**
*Action: Open the Scenario Builder and generate the 3-day Heat Simulator.*
"Now for scenario generation. If temperatures breach 30°C for 72 hours, how does this affect ICU constraints?
Our backend crunches over 2,000 trajectory paths mapping expected admissions leveraging Poisson distribution trees against the explicitly configured static limits (Beds, Ambulances, Staffing, and Inventory Accumulation)."

**2:15 - 3:00 | What-if Risk Mitigation**
*Action: Open Resource Risk showing Exceedance probabilities. Alter the Capacity baseline to demonstrate What-If.*
"This translates to Operational Language—showing the Exceedance Probability metric.
For a final assessment, ops managers can see what adding 10 Staffed ICU beds does to alter the exceedance footprint keeping identical environmental seed constraints, ensuring accurate apples-to-apples comparisons.
All changes invalidate previous un-trusted states ensuring no async state delays obscure reality for emergency managers."
