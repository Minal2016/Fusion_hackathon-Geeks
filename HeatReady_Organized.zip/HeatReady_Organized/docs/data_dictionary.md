# Data Dictionary

## Ingested CSV Data
* `month`: Timestamp string (YYYY-MM). Must be contiguous without missing calendar offsets.
* `provider`: Alphanumeric string referencing a hospital or provider group.
* `attendances`: Nonnegative whole count mapping to historical incoming activity in A&E context.
* `admissions`: Nonnegative whole count representing secondary escalation branching via `attendances`.

## Capacity Configurations
* `total_beds`: Concurrently staffed and ready operational beds. (Excluding unstaffed spatial capacity).
* `icu_beds`: Subset cap within `total_beds`.
* `ambulance_capacity_hours`: Active transport coverage bandwidth measured in unit hours/day.
* `clinical_staff_hours`: Active coverage per shift bandwidth in unit hours/day.
* `inventory_units`: Count generic representing cumulative constraint bounding for consumption across horizon.

## Generated Assumptions (Scenario Outputs)
* `p10`, `p50`, `p90`: Confidence limits representing the boundaries encapsulating variance across the 2,000 MC executed paths.
* `exceedance probability`: Bounded `[0.0, 1.0]` fraction characterizing density of scenarios crossing the capacity constraint.
