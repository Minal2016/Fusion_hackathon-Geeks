# Methodology

## Data Honesty
All generated data is explicitly tagged as `Synthetic demo data`. All heat and resource conversion extrapolations are tagged as an `Assumption-based scenario`. We strictly avoid hallucinating probabilities, preferring transparent computational models using robust seeds instead.

## Forecasting
### Core Models
We implement three distinct forecast techniques:
1. **Same Month Last Year (Lag 12)**
2. **Recent 3-Month Average**
3. **Seasonally Adjusted Baseline**

### Evaluation Strategy
We employ an expanding rolling window evaluated on the final 12 chronological holdout months. Whichever model minimizes the Mean Absolute Error (MAE) on the holdout window is chosen as the deterministic base logic.

### Uncertainty Simulation
We utilize residuals identified on the holdout evaluation set to bound empirical ranges representing P10/P50/P90 boundaries for probabilistic evaluation without deploying blackbox LLM techniques.

## Heat Range Simulation
Our simulation methodology generates > 2000 Monte Carlo trajectories utilizing the forecasted models alongside user configuration inputs:

1. **Draw Base Arrivals**: Poisson distribution scaling base forecasted demand.
2. **Evaluate Heat Burden**: Scales parametrically based on maximum daily degrees above the configured baseline threshold.
3. **Simulate Pathways**: Admission draws use Binomial distributions branching probabilistically towards ICU admission, staffing hours, and cumulative generic inventory.
4. **Aggregate Results**: Evaluates the trajectories finding fraction bounds representing Probability of Exceedance.
