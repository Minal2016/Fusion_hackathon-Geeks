@echo off
cd /d "%~dp0backend"
where py >nul 2>nul || (echo Python launcher not found. Install Python 3.11 or 3.12.& pause & exit /b 1)
if not exist .venv\Scripts\python.exe (py -3 -m venv .venv || (pause & exit /b 1))
.venv\Scripts\python.exe -m pip install -r requirements.txt || (pause & exit /b 1)
echo.
echo Backend: http://127.0.0.1:8000/docs
echo Firebase credentials are required for database endpoints.
.venv\Scripts\python.exe -m uvicorn app.main:app --reload --port 8000
pause
