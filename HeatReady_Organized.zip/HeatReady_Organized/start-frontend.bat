@echo off
cd /d "%~dp0frontend"
where npm >nul 2>nul || (echo Node.js/npm not found. Install Node.js LTS.& pause & exit /b 1)
if not exist node_modules (call npm install || (pause & exit /b 1))
echo Dashboard: http://localhost:5173
call npm run dev
pause
